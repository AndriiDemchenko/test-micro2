import { env } from './env';

export const GRCP_AUTH_URL = env.GRCP_AUTH_URL;
export const GRCP_CONFLICT_URL = env.GRCP_CONFLICT_URL;
