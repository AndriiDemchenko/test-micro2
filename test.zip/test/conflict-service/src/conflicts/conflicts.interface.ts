export enum SurveyStatus {
  Active = 'active',
}

// NOTE: update proto also
export interface GRcpConflict {
  id: number;
}
