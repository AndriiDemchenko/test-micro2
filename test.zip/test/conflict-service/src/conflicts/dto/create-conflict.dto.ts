export class CreateConflictDto {}
