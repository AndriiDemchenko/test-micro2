import { env } from './env';

export const GRCP_URL = env.GRCP_URL;
export const GRCP_AUTH_URL = env.GRCP_AUTH_URL;
