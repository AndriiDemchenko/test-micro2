require('./server').start()
