module.exports = {
  ...require('./environment-error'),
};
