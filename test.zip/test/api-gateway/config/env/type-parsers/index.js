module.exports = {
  string: require('./string'),
  number: require('./number'),
  boolean: require('./boolean'),
  arrayOfStrings: require('./array-of-strings'),
};
