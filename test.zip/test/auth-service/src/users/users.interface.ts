export enum UserStatus {
  Active = 'active',
}
