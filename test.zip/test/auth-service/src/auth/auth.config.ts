export { JWT_SECRET } from '../config/jwt';

export const USER_PASSWORD_MIN_LEN = 8;
export const USER_PASSWORD_MAX_LEN = 10;

export const ACCESS_TOKEN_SALT_ROUNDS = 10;
