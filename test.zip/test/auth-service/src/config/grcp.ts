import { env } from './env';

export const GRCP_URL = env.GRCP_URL;
