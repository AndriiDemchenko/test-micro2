import { env } from './env';

export const JWT_SECRET = env.JWT_SECRET;
