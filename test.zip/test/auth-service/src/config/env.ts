import { EnvironmentVariables } from 'src/env.validation';

export const env = process.env as unknown as EnvironmentVariables;
