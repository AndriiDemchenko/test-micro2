import { env } from './env';

export const PORT = env.PORT;
